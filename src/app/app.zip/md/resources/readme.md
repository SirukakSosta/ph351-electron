# Resources

- Skript_sim_methods_I.pdf, page 14 